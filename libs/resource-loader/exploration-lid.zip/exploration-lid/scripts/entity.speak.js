const util = require('util')
module.exports = function ({ system, engine, entity, interlocutor, speech, volume }) {
  const oEntity = engine.getEntity(entity)
  const oInterloc = engine.getEntity(interlocutor)
  if (oInterloc.blueprint.type === engine.CONST.ENTITY_TYPES.PLAYER) {
    const context = system.players[oInterloc.uid].context
    switch (volume) {
      case engine.CONST.VOLUME_NORMAL:
        context.print(util.format('{icon fas fa-comment-dots} {em %s}: %s', oEntity.name, speech))
        break

      case engine.CONST.VOLUME_ECHO:
        context.print(util.format('{icon fas fa-comment-dots} {em %s}: {i {warn %s}}', oEntity.name, speech))
        break

      case engine.CONST.VOLUME_SHOUT:
        context.print(util.format('{icon fas fa-bullhorn} {em %s}: {warn %s}', oEntity.name, speech.toUpperCase()))
        break
    }
  }
}
