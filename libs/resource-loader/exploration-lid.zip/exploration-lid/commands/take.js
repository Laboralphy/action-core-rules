const { ENTITY_TYPES.ITEM } = require('app/libs/mud/consts')
const rx = require('../../../../rxd-keywords')
const common = require('../common')

function help () {
  return [
    {
      section: 'Commande',
      text: 'Take - action de prendre un objet.'
    },
    {
      section: 'Syntaxe',
      text: 'take {i objet} [{i nombre}]'
    },
    {
      section: 'Description',
      text: [
        "Cette commande permet de prendre un objet visible dans la pièce où l'on se trouve ou dans le contenant que l'on vient d'ouvrir.",
        "Si l'objet est empilable, on peut spécifier le nombre d'exemplaires qu'on souhaite prendre en le spécifiant dans le deuxième paramètre.",
        "Si le joueur a récemment ouvert un contenant (coffre, armoire...) à l'aide de la commande {link \"help open\" open}, l'objet sera pris depuis contenant.",
        "Si le joueur a récemment fermé un contenant à l'aide de la commande {link \"help close\" close}, ou s'il vient d'entrer dans une pièce, l'objet sera pris directement parmis ceux qui traînent dans la pièce."
      ]
    },
    {
      section: 'Paramètres',
      text: "objet : Un identifiant local d'objet. Ces identifiants sont visibles grâce à la commande {link \"help look\", look}. Les objets enfermés dans un contenant sont visibles avec la commande {link \"help open\" open}."
    }
  ]
}

function takeContainerItem (context, lid, lidContainer, count = Infinity) {
  const { engine, print, pid, text, abort } = context
  const oPlayer = engine.getEntity(pid)
  // resoudre le container
  const oContainer = common.getLocalContainer(context, lidContainer)
  if (oContainer.trapped) {
    common.springTrap(context, oContainer.id)
    return
  }
  if (oContainer.locked) {
    print(text('action.youFailLookInContainer'))
    return
  }
  // l'objet
  const oObject = engine.getLocalEntity(lid, oContainer.id)
  if (!oObject) {
    abort('error.entityNotFound')
  }
  if (oObject.blueprint.type !== engine.CONST.ENTITY_TYPES.ITEM) {
    abort('error.entityTypeNotSuitable')
  }
  const oTransfer = engine.moveEntity(oObject.id, pid, count)
  print(text('action.youTakeItemFromContainer', { item: oTransfer.name, container: oContainer.name }))
  print.room(text('action.playerTakeItemFromContainer', { player: oPlayer.name, item: oTransfer.name, container: oContainer.name }))
}

/**
 *
 * @param engine {Engine}
 * @param print
 * @param command
 * @param pid
 * @param lid
 * @param count
 * @param text
 * @param abort
 */
function takeRoomItem ({ engine, print, pid, text, abort }, lid, count = Infinity) {
  const oPlayer = engine.getEntity(pid)
  const idRoom = oPlayer.location
  const oObject = engine.getLocalEntity(lid, idRoom)
  if (!oObject) {
    abort('error.entityNotFound')
  }
  if (oObject.blueprint.type !== ENTITY_TYPES.ITEM) {
    abort('error.entityTypeNotSuitable')
  }
  const oTransfer = engine.moveEntity(oObject.id, pid, count)
  print(text('action.youTakeItem', { item: oTransfer.name }))
  print.room(text('action.playerTakeItem', { player: oPlayer.name, item: oTransfer.name }))
}

function main (context, ...params) {
  rx.dispatch([
    {
      tests: [rx.LID, rx.UINT, rx.IN, rx.LID],
      handler: (lid, count, from, lidContainer) => takeContainerItem(context, lid, lidContainer, count)
    },
    {
      tests: [rx.LID, rx.IN, rx.LID],
      handler: (lid, from, lidContainer) => takeContainerItem(context, lid, lidContainer)
    },
    {
      tests: [rx.LID, rx.UINT],
      handler: (lid, count) => takeRoomItem(context, lid, count)
    },
    {
      tests: [rx.LID],
      handler: lid => takeRoomItem(context, lid)
    },
    {
      handler: () => context.abort('badUsage')
    }
  ], params)
}

module.exports = main
