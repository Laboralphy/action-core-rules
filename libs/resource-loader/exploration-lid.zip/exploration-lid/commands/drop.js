const rx = require('../../../../rxd-keywords')
const common = require('../common')

function help () {
  return [
    {
      section: 'Commande',
      text: 'Take - action de prendre un objet.'
    },
    {
      section: 'Syntaxe',
      text: 'take {i objet} [{i nombre}]'
    },
    {
      section: 'Description',
      text: [
        "Cette commande permet de prendre un objet visible dans la pièce où l'on se trouve ou dans le contenant que l'on vient d'ouvrir.",
        "Si l'objet est empilable, on peut spécifier le nombre d'exemplaires qu'on souhaite prendre en le spécifiant dans le deuxième paramètre.",
        "Si le joueur a récemment ouvert un contenant (coffre, armoire...) à l'aide de la commande {link \"help open\" open}, l'objet sera pris depuis contenant.",
        "Si le joueur a récemment fermé un contenant à l'aide de la commande {link \"help close\" close}, ou s'il vient d'entrer dans une pièce, l'objet sera pris directement parmis ceux qui traînent dans la pièce."
      ]
    },
    {
      section: 'Paramètres',
      text: "objet : Un identifiant local d'objet. Ces identifiants sont visibles grâce à la commande {link \"help look\", look}. Les objets enfermés dans un contenant sont visibles avec la commande {link \"help open\" open}."
    }
  ]
}

function dropContainerItem (context, lid, lidContainer, count = Infinity) {
  const { engine, print, pid, text, abort } = context
  // il faut que lid soit dans notre inventaire
  const oPlayer = engine.getEntity(pid)
  // resoudre l'objet
  const oItem = engine.getLocalEntity(lid, pid)
  if (!oItem) {
    // on n'a pas cet objet
    abort('error.entityNotFound')
  }
  // resoudre le container
  const oContainer = common.getLocalContainer(context, lidContainer)
  // est ce bien un container ?
  if (!oContainer.inventory) {
    abort('error.containerNotFound')
  }
  // ce container peut être dans la pièces ou dans l'inventaire
  const oTransfer = engine.moveEntity(oItem.id, oContainer.id, count)
  print(text('action.youDropInFromContainer', { item: oTransfer.name, container: oContainer.name }))
  print.room(text('action.playerDropInFromContainer', { player: oPlayer.name, item: oTransfer.name, container: oContainer.name }))
}

/**
 *
 * @param engine {MUDEngine}
 * @param print
 * @param command
 * @param pid
 * @param lid
 * @param count
 * @param text
 * @param abort
 */
function dropRoomItem ({ engine, print, command, pid, text, abort }, lid, count = Infinity) {
  const oPlayer = engine.getEntity(pid)
  const idRoom = oPlayer.location
  const oItem = engine.getLocalEntity(lid, pid)
  if (!oItem) {
    abort('error.entityNotFound')
  }
  const oTransfer = engine.moveEntity(oItem.id, idRoom, count)
  print(text('action.youDropItem', { item: oTransfer.name }))
  print.room(text('action.playerDropItem', { player: oPlayer.name, item: oTransfer.name }))
}

function main (context, ...params) {
  rx.dispatch([
    {
      tests: [rx.LID, rx.UINT, rx.IN, rx.LID],
      handler: (lid, count, from, lidContainer) => dropContainerItem(context, lid, lidContainer, count)
    },
    {
      tests: [rx.LID, rx.IN, rx.LID],
      handler: (lid, from, lidContainer) => dropContainerItem(context, lid, lidContainer)
    },
    {
      tests: [rx.LID, rx.UINT],
      handler: (lid, count) => dropRoomItem(context, lid, count)
    },
    {
      tests: [rx.LID],
      handler: lid => dropRoomItem(context, lid)
    },
    {
      handler: () => context.abort('badUsage')
    }
  ], params)
}

module.exports = main
