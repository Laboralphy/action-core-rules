const rx = require('../../../../rxd-keywords')
const common = require('../common')

function help () {
  return [
    {
      section: 'Commande',
      text: 'Disarm - Commande de désarmement de piège.'
    },
    {
      section: 'Syntaxe',
      text: [
        'disarm {i direction}',
        'disarm {i contenant}'
      ]
    },
    {
      section: 'Description',
      text: [
        'Cette action permet de désarmer un piège que vous avez précédemment détecté (avec la commande {link "help search" search}).',
        "La commande s'utilise sur une direction ou sur un objbet fixe, de type contenant."
      ]
    },
    {
      section: 'Paramètres',
      text: [
        'direction : une direction parmi les suivantes : n: nord, e: est, w: ouest, s: sud, ne: nord-est, nw: nord-ouest, se: sud-est, sw: sud-ouest.',
        "contenant : identifiant local d'un contenant."
      ]
    }
  ]
}

function disarmDirection (context, sDirection) {
  const { pid, engine, print, text } = context
  const oExitStatus = engine.getEntityExit(pid, sDirection)
  const oPlayer = engine.getEntity(pid)
  // ce container est piégé et visible ?
  if (oExitStatus.trapped && oExitStatus.trapVisible) {
    // difficulté vs skill
    if (engine.resolveTaskOutcome(pid, 'disarm', oExitStatus.dcDisarm)) {
      // on désarme le piège
      oExitStatus.trapped = false
      print(text('action.youDisarmTrap', { dir: sDirection }))
      print.room(text('action.playerDisarmTrap', { player: oPlayer.name, dir: sDirection }))
    } else {
      // on n'arrive pas a desarmorcer
      print(text('action.youFailDisarmTrap', { dir: sDirection }))
      print.room(text('action.playerFailDisarmTrap', { player: oPlayer.name, dir: sDirection }))
    }
  } else {
    print(text('action.youCannotDisarmWhatYouDontSee'))
  }
}

function disarmContainer (context, lid) {
  const { pid, engine, print, text } = context
  const oContainer = common.getLocalContainer(context, lid)
  const oPlayer = engine.getEntity(pid)
  // ce container est piégé et visible ?
  if (oContainer.trapped && engine.hasPlayerSpottedTrap(pid, oContainer.id)) {
    // difficulté vs skill
    if (engine.resolveTaskOutcome(pid, 'disarm', oContainer.blueprint.trap.difficulty)) {
      // on désarme le piège
      oContainer.trapped = false
      print(text('action.youDisarmContainerTrap', { container: oContainer.name }))
      print.room(text('action.playerDisarmContainerTrap', { player: oPlayer.name, container: oContainer.name }))
    } else {
      // on n'arrive pas a desarmorcer
      print(text('action.youFailDisarmTrap', { container: oContainer.name }))
      print.room(text('action.playerFailDisarmContainerTrap', { player: oPlayer.name, container: oContainer.name }))
    }
  } else {
    print(text('action.youCannotDisarmWhatYouDontSee'))
  }
}

function main (context, ...params) {
  rx.dispatch([
    {
      tests: [rx.DIR],
      handler: sDirection => disarmDirection(context, sDirection)
    },
    {
      tests: [rx.LID],
      handler: lid => disarmContainer(context, lid)
    }
  ], params)
}

module.exports = main
