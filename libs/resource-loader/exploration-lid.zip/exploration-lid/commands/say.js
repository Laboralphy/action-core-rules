function main (context, ...text) {
  const { engine, pid } = context
  const sText = text.join(' ')
  const oPlayer = engine.getEntity(pid)
  engine.speakString(pid, oPlayer.location, sText)
}

module.exports = main
