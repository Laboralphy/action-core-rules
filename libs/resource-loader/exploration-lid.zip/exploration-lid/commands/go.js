const rx = require('../../../../rxd-keywords')
const common = require('../common')

function help () {
  return [
    {
      section: 'Commande',
      text: 'Go - action de déplacement dans le monde.'
    },
    {
      section: 'Syntaxe',
      text: 'go {i direction}'
    },
    {
      section: 'Description',
      text: "Cette action permet d'emprunter une issue pour passer d'une pièce à une autre. Cette action peut échouer si la direction spécifiée ne correspond pas à une issue valide, ou bien si l'issue est infranchissable (verrouillée)."
    },
    {
      section: 'Paramètres',
      text: 'direction : une direction parmis les suivantes : n: nord, e: est, w: ouest, s: sud, ne: nord-est, nw: nord-ouest, se: sud-est, sw: sud-ouest.'
    }
  ]
}

function goDirection (context, sDirection) {
  const { print, engine, pid, text } = context
  const { valid, visible, locked, destination } = engine.getEntityExit(pid, sDirection)
  if (valid && visible && !locked) {
    const oPlayer = engine.getEntity(pid)
    const idSector = engine.getRoom(oPlayer.location).sector
    print.room(text('action.playerExitRoom', { dir: sDirection, player: oPlayer.name }))
    engine.moveEntity(pid, destination)
    const oNewRoom = engine.getRoom(destination)
    print(text('action.youMoveRoom', { dir: sDirection, room: oNewRoom.name }))
    print.room(text('action.playerEnterRoom', { dir: sDirection, player: oPlayer.name }))
    // notifier le player que la map change
    const idNewSector = engine.getRoom(oPlayer.location).sector
    if (idNewSector !== idSector) {
      engine.command('look', ['sector'])
    }
  } else {
    if (locked) {
      print(text('action.exitIsLocked', { dir: sDirection }))
    } else {
      print(text('action.noExitHere', { dir: sDirection }))
    }
  }
}

function main (context, ...params) {
  // verifie le paramètre direction
  rx.dispatch([
    {
      tests: [rx.DIR],
      handler: sDirection => goDirection(context, sDirection)
    },
    {
      // ne correspond à aucune configuration
      handler: () => context.abort('badUsage')
    }
  ], params)
}

module.exports = main
