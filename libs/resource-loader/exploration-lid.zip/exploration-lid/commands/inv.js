function help () {
  return [
    {
      section: 'Commande',
      text: 'Inv - consulter un inventaire.'
    },
    {
      section: 'Syntaxe',
      text: 'inv'
    },
    {
      section: 'Description',
      text: [
        'Cette commande permet de consulter son propre inventaire.',
        "C'est un alias de la commande {link \"help look\" look inv}."
      ]
    }
  ]
}

function main (context) {
  context.command('look', 'inv')
}

module.exports = main
