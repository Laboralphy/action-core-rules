const rx = require('../../../../rxd-keywords')

function help () {
  return [
    {
      section: 'Commande',
      text: 'Search - Recherche de passages secrets.'
    },
    {
      section: 'Syntaxe',
      text: 'search {i direction}'
    },
    {
      section: 'Description',
      text: "Cette action permet d'effectuer une recherche de passages secrets. Certaines portes sont, en effet, camouflées et on ne peut pas les voir lorsqu'on regarde la pièce avec la commande {link \"help look\" look}. Seule une recherche permet de mettre les portes cachées en évidence."
    },
    {
      section: 'Paramètres',
      text: 'direction : une direction parmi les suivantes : n: nord, e: est, w: ouest, s: sud, ne: nord-est, nw: nord-ouest, se: sud-est, sw: sud-ouest.'
    }
  ]
}

/**
 * Chercher dans une direction s'il existe une issue secrete, ou si l'issue visible est piégée
 * @param context
 * @param sDirection
 */
function searchDirection (context, sDirection) {
  const { text, print, engine, pid, abort } = context
  const { valid, secret, visible, dcSearch } = engine.getEntityExit(pid, sDirection)
  // obtenir valeur skill
  // déterminer succès
  // a-t-on besoin de détecter la porte ?
  const bNeedDetectExit = valid && secret && !visible
  const oPlayer = engine.getEntity(pid)
  const idRoom = oPlayer.location
  const aOtherPlayers = engine.getLocalEntities(idRoom)
    .filter(({ id, entity }) => entity.blueprint.type === engine.CONST.ENTITY_TYPES.PLAYER)
    .map(({ entity }) => entity)
  let oDS = engine.getEntityExit(pid, sDirection)
  if (!oDS.visible && bNeedDetectExit && engine.resolveTaskOutcome(pid, 'search', dcSearch)) {
    // partager la découverte avec les autres joueurs de la pièce
    aOtherPlayers
      .forEach(p => {
        const idPlayer = p.id
        engine.setEntityExitSpotted(idPlayer, sDirection, true)
      })
    // on a découvert une nouvelle porte cachée : le dire à tous
    print(text('action.youFoundSecretExit', { dir: sDirection }))
    print.room(text('action.playerFoundSecretExit', { player: oPlayer.name, dir: sDirection }))
  } else if (!oDS.visible) {
    // on n'arrive pas à déceler la porte
    print(text('action.youFailSearchSecret', { dir: sDirection }))
    return // inutile d'aller chercher un piège sur une issue invisible
  }
  oDS = engine.getEntityExit(pid, sDirection)
  if (oDS.valid && oDS.visible) {
    // la porte est visible
    print(text('action.youFailSearchTrapExit', { dir: sDirection }))
  } else {
    abort('error.entityTypeNotSuitable')
  }
}

function searchContainer (context, lid) {
  const { text, print, engine, pid, abort } = context
  const oPlayer = engine.getEntity(pid)
  const oContainer = engine.getLocalEntity(lid, oPlayer.location)
  if (!oContainer) {
    abort('error.entityNotFound')
  }
  if (oContainer.blueprint.type === engine.CONST.ENTITY_TYPES.PLACEABLE) {
    if (oContainer.trapped && !engine.hasPlayerSpottedTrap(pid, oContainer.id)) {
      if (engine.resolveTaskOutcome(pid, 'search', oContainer.blueprint.trap.difficulty)) {
        // piège détecté
        print(text('action.youFoundTrappedContainer', { container: oContainer.name }))
        print.room(text('action.playerFoundTrappedContainer', { player: oPlayer.name, container: oContainer.name }))
        engine.setEntityTrapSpotted(pid, oContainer.id, true)
        return
      }
    }
    // pas de piège détecté
    print(text('action.youFailSearchTrapContainer', { container: oContainer.name }))
  } else {
    abort('error.entityTypeNotSuitable')
  }
}

function main (context, ...params) {
  rx.dispatch([
    {
      tests: [rx.DIR],
      handler: sDirection => searchDirection(context, sDirection)
    },
    {
      tests: [rx.LID],
      handler: lid => searchContainer(context, lid)
    },
    {
      // ne correspond à aucune configuration
      handler: () => context.abort('error.badUsage')
    }
  ], params)
}

module.exports = main
