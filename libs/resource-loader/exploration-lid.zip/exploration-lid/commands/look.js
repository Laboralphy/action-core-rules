const rx = require('../../../../rxd-keywords')
const common = require('../common')

function help () {
  return [
    {
      section: 'Commande',
      text: "Look - action d'examen d'objet, créature ou pièce."
    },
    {
      section: 'Syntaxe',
      text: 'look [{i objet | issue}] [{i in}] [{i contenant}]'
    },
    {
      section: 'Description',
      text: [
        "Cette action permet d'examiner tout ce qui est visible :",
        "- La pièce où l'on se trouve ainsi que les objets dans cette pièce.",
        '- La liste des objet contenu dans un contenant.',
        "- les détails d'une issue (verrou).",
        '- son propre inventaire.',
        'Lancée sans paramètre, la commande affiche une description de la pièce dans laquelle on se trouve, ainsi que' +
        " la liste des entité visibles (objets, créatures). Chaque entité est listée avec un identifiant local qu'il" +
        " est possible de réutiliser en paramètre pour examiner en détaille l'objet ou la créature concernée.",
        "Lancée avec un identifiant local, la commande permet d'examiné l'objet correspondant.",
        "Si le mot-clé 'in' est utilisé, la commande permet d'examiner le contenu d'une objet (s'il possède un inventaire).",
        'Pour examiner son propre inventaire, il faut utiliser {link "look inv" look inv}.'
      ]
    },
    {
      section: 'Paramètres',
      text: [
        "- objet : (optionel) Un identifiant local d'objet. Ces identifiants sont visibles quand on lance la commande sans paramètres.",
        "- issue : (optionel) l'une des direction valide de la pièce."
      ]
    },
    {
      section: 'Exemples',
      text: [
        "- look : regarder ce qu'il y a dans la pièce.",
        "- look inv : regarder ce qu'il y a dans son inventaire",
        "- look u3 : regarder l'objet u3 de son inventaire (les identifiant commençant par 'u' sont des objets d'inventaire).",
        "- look i2 in o1 : regarder l'objet i2 situé dans le contenant o1 (les identifiant commençant par 'o' sont des identifiant d'objets fixes contenu dans la pièce)."
      ]
    }
  ]
}

/**
 * description d'un inventaire
 * @param context
 * @param idContainer
 * @returns {{container: *, inventory: {}}}
 */
function getInventoryDescriptor (context, idContainer) {
  const { engine, pid, text } = context
  const aEntities = engine
    .getLocalEntities(idContainer)
    .filter(e => e.id !== pid)
    .map(({ lid, entity }) => ({
      lid,
      type: entity.blueprint.type,
      name: entity.name,
      dead: entity.dead
    }))
  const re = {}
  for (const { lid, type, name, dead } of aEntities) {
    if (!(type in re)) {
      re[type] = []
    }
    re[type].push({ lid, name, dead })
  }
  return Object.keys(re).map(type => ({ type: text('entityType.' + type, { count: re[type].length }), entities: re[type] }))
}

/**
 * Descriptif de l'état d'un verrou. Cette fonction peut servir pour une porte ou pour un contenant
 * @param locked {boolean} verrouillé / non-verrouillé
 * @param lockable {boolean} déverrouillé, mais re-verrouillable
 * @param keyLock {boolean} présence d'une serrure à clé
 * @param codeLock {boolean} présence d'un digicode
 * @returns {{locked: boolean, by: string, desc: string}|null}
 */
function getLockDescriptor (locked, lockable, keyLock, codeLock) {
  return locked
    ? keyLock
      ? { locked: true, by: 'key', desc: '' }
      : codeLock
        ? { locked: true, by: 'code', desc: '' }
        : { locked: true, by: 'locked', desc: '' }
    : lockable
      ? { locked: false, by: 'none', desc: '' }
      : null
}

/**
 * Comme pour les porte, certaines entité munies d'un inventaire peuvent avoir un verrou
 * @param context
 * @param idEntity
 * @returns {{locked: boolean, by: string, desc: string}|null}
 */
function getEntityLockDescriptor (context, idEntity) {
  const { engine, text } = context
  const oEntity = engine.getEntity(idEntity)
  const locked = oEntity.locked
  const lockable = !!oEntity.blueprint.lock
  const keyLock = lockable && oEntity.blueprint.lock.key !== ''
  const codeLock = lockable && oEntity.blueprint.lock.code !== ''
  const oLock = getLockDescriptor(locked, lockable, keyLock, codeLock)
  if (oLock) {
    oLock.desc = text('lockStatus.' + oLock.by)
  }
  return oLock
}

/**
 * Construit la structure de description d'une issue
 * @param context {object}
 * @param sDirection {string} direction
 * @returns {(*&{valid: boolean, name, destination, direction: *, desc})|{valid: boolean}}
 */
function getExitDescriptor (context, sDirection) {
  const { pid, engine, text } = context
  const oExitStatus = engine.getEntityExit(pid, sDirection)
  if (oExitStatus.valid && oExitStatus.visible) {
    const locked = oExitStatus.locked
    const lockable = oExitStatus.lockable
    const keyLock = lockable && oExitStatus.key !== ''
    const codeLock = lockable && oExitStatus.code !== ''
    const lock = getLockDescriptor(locked, lockable, keyLock, codeLock)
    if (lock) {
      lock.desc = text('lockStatus.' + lock.by)
    }
    return {
      labels: {
        direction: text('labels.direction'),
        navTo: text('labels.nextRoom'),
        lockStatus: text('labels.lockStatus')
      },
      valid: true,
      dir: oExitStatus.direction,
      vdir: text('dir.' + oExitStatus.direction),
      name: oExitStatus.name,
      destination: engine.getRoom(oExitStatus.destination).name,
      desc: oExitStatus.desc,
      lock
    }
  } else {
    return {
      valid: false
    }
  }
}

/**
 * Construit la structure de description de la pièce dans laquelle se trouve le joueur
 * @param context {object}
 * @returns {{exits: (*|{valid: boolean})[], entities: (boolean|*), name, desc}}
 */
function getRoomDescriptor (context) {
  const { text, engine, pid } = context
  const idRoom = engine.getEntity(pid).location
  const oRoom = engine.getRoom(idRoom)
  const exits = engine
    .getRoomValidExits(idRoom)
    .map(direction => getExitDescriptor(context, direction))
    .filter(({ valid }) => valid)
    .map(({ dir, vdir, name, destination, locked, lock, trapped }) => ({
      dir, // code de direction
      vdir, // label de direction
      name: locked ? name : destination, // nom de la porte si fermée
      lock, // verrou
      trapped
    }))
  return {
    id: idRoom,
    labels: {
      exits: text('entityType.exit', { count: exits.length }),
      danger: text('trapStatus.danger'),
      corpse: text('labels.corpse')
    },
    name: oRoom.name,
    desc: oRoom.desc,
    exits,
    inventory: getInventoryDescriptor(context, idRoom)
  }
}

function getPlayerDescriptor (context, idEntity) {
  /*
    name, // nom de la créature
    desc // description de la créature
   */
  const { text, engine } = context
  const oActor = engine.getEntity(idEntity)
  return {
    id: oActor.id,
    name: oActor.name,
    desc: oActor.desc,
    labels: {
      player: text('labels.sentience')
    }
  }
}

/**
 * Renvoie un descriptif d'une créature
 * @param context {*}
 * @param idEntity {string}
 */
function getActorDescriptor (context, idEntity) {
/*
  name, // nom de la créature
  desc, // description de la créature
  hostile,
  dead,
  labels: {
    reaction,
    hostile,
    neuter
  }
 */
  const { text, engine } = context
  const oActor = engine.getEntity(idEntity)
  return {
    id: oActor.id,
    name: oActor.name,
    desc: oActor.desc,
    hostile: true,
    dead: oActor.dead,
    labels: {
      reaction: text('labels.reaction'),
      hostile: text('labels.hostile'),
      neuter: text('labels.neuter'),
      actorDead: text('labels.actorDead', { context: 'm' })
    }
  }
}

/**
 * Renvoie un descriptif d'un placeable
 * @param context
 * @param idEntity
 * @returns {*}
 */
function getPlaceableDescriptor (context, idEntity) {
  const { engine, text, pid } = context
  const oEntity = engine.getEntity(idEntity)
  return {
    labels: {
      inContainer: text('labels.in'),
      lockStatus: text('labels.lockStatus'),
      contains: text('labels.contains'),
      empty: text('labels.emptyInventory'),
      hasInventory: text('labels.hasInventory'),
      danger: text('trapStatus.danger')
    },
    id: oEntity.id,
    name: oEntity.name,
    desc: oEntity.desc,
    lock: getEntityLockDescriptor(context, idEntity),
    trapped: oEntity.trapped && engine.hasPlayerSpottedTrap(pid, oEntity.id),
    container: common.getContainerName(context, idEntity),
    hasInventory: !!oEntity.inventory
  }
}

function getItemDescriptor (context, idEntity) {
  const { engine, text } = context
  const oEntity = engine.getEntity(idEntity)
  return {
    labels: {
      lockStatus: text('labels.lockStatus'),
      inContainer: text('labels.in'),
      weight: text('labels.weight'),
      inventory: text('labels.inventory'),
      contains: text('labels.contains'),
      empty: text('labels.emptyInventory'),
      hasInventory: text('labels.hasInventory')
    },
    id: oEntity.id,
    container: common.getContainerName(context, idEntity),
    name: oEntity.name,
    desc: oEntity.desc,
    weight: oEntity.weight,
    lock: getEntityLockDescriptor(context, idEntity),
    hasInventory: !!oEntity.inventory
  }
}

function lookInContainer (context, lidContainer) {
  const { print, text, engine, pid } = context
  const idRoom = engine.getEntity(pid).location
  const oRoom = engine.getRoom(idRoom)
  const oContainer = common.getLocalContainer(context, lidContainer)
  const aInvDesc = getInventoryDescriptor(context, oContainer.id)
  if (oContainer.trapped) {
    common.springTrap(context, oContainer.id)
    return
  }
  if (oContainer.locked) {
    print(text('action.youFailLookInContainer'))
    return
  }
  const data = {
    id: oContainer.id,
    room: oRoom.name,
    locked: oContainer.locked,
    name: oContainer.name,
    inventory: aInvDesc.length > 0 ? aInvDesc[0].entities : [],
    labels: {
      inContainer: text('labels.in'),
      locked: text('lockStatus.locked'),
      empty: text('labels.emptyInventory')
    }
  }
  print('look/in-placeable', data)
}

function lookInPlayerInventory (context) {
  const { print, text, pid } = context
  const aInvDesc = getInventoryDescriptor(context, pid)
  const data = {
    locked: false,
    name: text('labels.yourInventory'),
    inventory: aInvDesc.length > 0 ? aInvDesc[0].entities : [],
    labels: {
      inContainer: text('labels.in'),
      locked: text('lockStatus.locked'),
      empty: text('labels.emptyInventory')
    }
  }
  print('look/in-placeable', data)
}

function lookItemInContainer (context, lid, lidContainer) {
  const { print, engine, pid, abort } = context
  const oContainer = common.getLocalContainer(context, lidContainer)
  // le conteneur existe
  const oItem = engine.getLocalEntity(lid, oContainer.id)
  if (oItem) {
    print('look/entity/item', getItemDescriptor(context, oItem.id))
  } else {
    abort('error.entityNotFoundInContainer')
  }
}

/**
 * On regarde une entité listée paris elles de la pièce.
 * @param context {object}
 * @param lid {string} local id de l'entité
 */
function lookEntity (context, lid) {
  const { print, engine, pid, abort } = context
  const oPlayer = engine.getEntity(pid)
  const idRoom = oPlayer.location
  let oEntity, idContainer = idRoom
  oEntity = engine.getLocalEntity(lid, idRoom)
  if (!oEntity) {
    idContainer = pid
    oEntity = engine.getLocalEntity(lid, pid)
  }
  if (oEntity) {
    switch (oEntity.blueprint.type) {
      case engine.CONST.ENTITY_TYPES.ITEM:
        print('look/entity/item', getItemDescriptor(context, oEntity.id, idContainer))
        break

      case engine.CONST.ENTITY_TYPES.PLACEABLE:
        print('look/entity/placeable', getPlaceableDescriptor(context, oEntity.id))
        break

      case engine.CONST.ENTITY_TYPES.ACTOR:
        print('look/entity/actor', getActorDescriptor(context, oEntity.id))
        break

      case engine.CONST.ENTITY_TYPES.PLAYER:
        print('look/entity/player', getPlayerDescriptor(context, oEntity.id))
        break
    }
  } else {
    abort('error.entityNotFound')
  }
}

/**
 * Affichage d'un descriptif de la direction spécifiée
 * @param context {object}
 * @param direction {string} direction dans laquelle on regarde
 */
function lookDirection (context, direction) {
  const { print, pid } = context
  const oDescriptor = getDoorDescriptor(context, direction)
  print('look/door', oDescriptor)
}

/**
 * Affichage d'un descriptif de la pièce dans laquel se trouve le joueur
 * @param context
 */
function lookRoom (context) {
  const { print, pid } = context
  const oDescriptor = getRoomDescriptor(context)
  print('look/room', oDescriptor)
}

/**
 * Affichage d'un descriptif du secteur dans lequel se trouve le joueur
 * @param context
 */
function lookSector (context) {
  const { pid, engine, print } = context
  const oSector = engine.getSector(engine.getRoom(engine.getEntity(pid).location).sector)
  print('look/sector', {
    ...oSector
  })
}

function main (context, ...params) {
  rx.dispatch([
    {
      tests: [rx.SECTOR],
      handler: () => lookSector(context)
    },
    {
      tests: [rx.INV],
      handler: () => lookInPlayerInventory(context)
    },
    {
      // un seul argument : un local id
      tests: [rx.LID],
      // c'est une entité située dans la pièce
      handler: lid => lookEntity(context, lid)
    },
    {
      // un seul argument : une direction
      tests: [rx.DIR],
      // on regarde la direction correspondante
      handler: sDirection => lookDirection(context, sDirection)
    },
    {
      // trois arguments : un premier local id, suivi de "IN", suivit d'un second local id
      tests: [rx.LID, rx.IN, rx.LID],
      // on regarde un item dans un contenant
      handler: (lidObject, sIn, lidContainer) => lookItemInContainer(context, lidObject, lidContainer)
    },
    {
      // deux arguments : "IN", suivit d'un local id
      tests: [rx.IN, rx.LID],
      // on regarde l'inventaire d'un contenant
      handler: (sIn, lidContainer) => lookInContainer(context, lidContainer)
    },
    {
      // aucun argument
      tests: [],
      // on regarde la pièce elle même
      handler: () => lookRoom(context)
    },
    {
      // ne correspond à aucune configuration
      handler: () => context.abort('badUsage')
    }
  ], params)
}

module.exports = main
