const rx = require('../../../../rxd-keywords')

function help () {
  return [
    {
      section: 'Commande',
      text: 'Lockpick - action de crochetage de serrure verrouillée.'
    },
    {
      section: 'Syntaxe',
      text: 'lockpick {i direction|objet}'
    },
    {
      section: 'Description',
      text: "Cette action permet de crocheter une serrure verrouillée. Si la valeur du talent de crochetage du joueur est supérieure ou égale à la difficulté de la serrure, le joueur réussit à déverrouiller la porte ou l'objet. "
    },
    {
      section: 'Paramètres',
      text: [
        'direction : Une direction parmis les suivantes : n: nord, e: est, w: ouest, s: sud, ne: nord-est, nw: nord-ouest, se: sud-est, sw: sud-ouest.',
        "objet : Identifiant local de l'objet. Cet identifiant peut-être listé grace à la commande {link \"help look\" look}."
      ]
    }
  ]
}

function lockpickContainer (context, lidContainer) {
  const { abort, text, pid, engine, print } = context
  const oPlayer = engine.getEntity(pid)
  const oContainer = engine.getLocalEntity(lidContainer, oPlayer.location)
  // le container doit être vérrouillé
  if (!oContainer) {
    abort('error.entityNotFound')
  }
  if (oContainer.locked) {
    // déterminer le skill du joueur
    if (engine.resolveTaskOutcome(pid, 'lockpick', oContainer.blueprint.lock.difficulty)) {
      // ouverture par crochetage
      oContainer.locked = false
      print(text('action.youLockpickContainer', { container: oContainer.name }))
      print.room(text('action.playerLockpickContainer', { container: oContainer.name }))
    } else {
      // impossible de crocheter
      print(text('action.youFailLockpickContainer', { container: oContainer.name }))
      print.room(text('action.playerFailLockpickContainer', { container: oContainer.name }))
    }
  } else {
    // sinon ce n'est pas la peine
    abort(text('error.notLocked'))
  }
}

function lockpickExit (context, sDirection) {
  const { abort, text, pid, engine, print } = context
  const oExitStatus = engine.getEntityExit(pid, sDirection)
  const oPlayer = engine.getEntity(pid)
  // la porte doit être vérrouillée
  if (oExitStatus.locked) {
    // déterminer le skill du joueur
    if (engine.resolveTaskOutcome(pid, 'lockpick', oExitStatus.dcLockpick)) {
      // ouverture par crochetage
      oExitStatus.locked = false
      print(text('action.youLockpickExit', { dir: sDirection }))
      print.room(text('action.playerLockpickExit', { dir: sDirection }))
    } else {
      // impossible de crocheter
      print(text('action.youFailLockpickExit', { dir: sDirection }))
      print.room(text('action.playerFailLockpickExit', { dir: sDirection }))
    }
  } else {
    // sinon ce n'est pas la peine
    abort(text('error.notLocked'))
  }
}

function main (context, ...params) {
  rx.dispatch([
    {
      tests: [rx.DIR],
      handler: sDirection => lockpickExit(context, sDirection)
    },
    {
      tests: [rx.LID],
      handler: lid => lockpickContainer(context, lid)
    },
    {
      // ne correspond à aucune configuration
      handler: () => context.abort('error.badUsage')
    }
  ], params)
}

module.exports = main
