const rx = require('../../../../rxd-keywords')
const common = require('../common')

function help () {
  return [
    {
      section: 'Commande',
      text: "Unlock - déverrouillage d'une porte."
    },
    {
      section: 'Syntaxe',
      text: 'unlock {i direction} [{i code}]'
    },
    {
      section: 'Description',
      text: [
        "Cette action permet de déverrouiller la porte dsignée par le paramètre de direction, soit  avec une clé en votre possession, soit avec un code qu'il faut spécifier en paramètre.",
        "Il n'est pas nécessaire de spécifier la clé à utiliser : Si votre personnage possède la clé correspondant à la serrure, la porte sera déverrouillée. Par contre pour les portes fermées avec un code, il est nécessaire de spécifier le code en paramètre."
      ]
    },
    {
      section: 'Paramètres',
      text: [
        "direction : pour désigner la porte que l'on souhaite déverrouiller.",
        "code : (optionel) Certaine portes exigent un code secret pour s'ouvrir."
      ]
    }
  ]
}

/**
 * Renvoie un descriptif du contenant par rapport au joueur.
 * le descriptif contient des information sur le verrou et le piège.
 * Si le contenant est piégé et que le joueur à déjà repéré le piège, cela sera noté dans lastructure de retour.
 * @typedef ContainerStatus {object} état d'un contenant tel qu'il est perçu par un joueur
 * @property trapped {boolean}
 * @property code {string}
 * @property trapVisible {string}
 * @property lockable {boolean}
 * @property dcLockpick {number}
 * @property dcDisarm {number}
 * @property trap {boolean}
 * @property trapTag {boolean}
 * @property locked {boolean}
 * @property discardKey {boolean}
 * @property key {string}
 *
 * @param context {object} contexte
 * @param idPlayer {string} identifiant du joueur
 * @param idEntity {string} identifiant de l'entité
 * @returns {ContainerStatus} état du contenant
 */
function getPlayerContainerStatus (context, idPlayer, idEntity) {
  const { engine } = context
  const oEntity = engine.getEntity(idEntity)
  const oLock = oEntity.blueprint.lock
  const oTrap = oEntity.blueprint.trap
  const bTrapSpotted = !!oTrap && engine.hasPlayerSpottedTrap(idPlayer, idEntity)
  return {
    lockable: !!oLock,
    locked: oEntity.locked,
    key: oLock ? oLock.key : '',
    code: oLock ? oLock.code : '',
    dcLockpick: oLock ? oLock.difficulty : 0,
    discardKey: oLock ? oLock.discardKey : false,
    // un piège possible pour les contenant fixés au sol
    trap: !!oTrap,
    trapped: oTrap ? oTrap.armed : false,
    trapVisible: bTrapSpotted,
    trapTag: oTrap ? oTrap.tag : '',
    dcDisarm: oTrap ? oTrap.difficulty : 0
  }
}


/**
 * Deverrouille la serrure d'un objet
 * @param context
 * @param lidContainer
 */
function unlockContainer (context, lidContainer) {
  const { print, engine, pid, text, abort } = context
  const oContainer = common.getLocalContainer(context, lidContainer)
  const oContStatus = getPlayerContainerStatus(context, pid, oContainer.id)
  if (!oContStatus.locked) {
    abort('error.notLocked')
  }
  const sTag = oContStatus.key
  if (!sTag) {
    // pas de clé pour ce conteneur
    abort('error.notKeyLocked')
  }
  // rechercher dans notre inventaire un item/clé ayant le tag
  const oKey = engine.findEntitiesByTag(sTag, pid).shift()
  if (oKey) {
    oContainer.locked = false
    if (oContStatus.discardKey) {
      engine.destroyEntity(oKey.id)
      print(text('action.youUnlockContainerKeyDiscard', { container: oContainer.name, key: oKey.name }))
    } else {
      print(text('action.youUnlockContainerKey', { container: oContainer.name, key: oKey.name }))
    }
  } else {
    print(text('action.youFailUnlockContainerKey', { container: oContainer.name }))
  }
}

/**
 * Deverrouille la serrure d'un objet
 * @param context
 * @param lidContainer
 */
function unlockContainerCode (context, lidContainer, sCode) {
  const { print, text, abort, pid, engine } = context
  const oContainer = common.getLocalContainer(context, lidContainer)
  const oContStatus = getPlayerContainerStatus(context, pid, oContainer.id)
  if (!oContStatus.locked) {
    abort('error.notLocked')
  }
  const oLock = oContainer.lock
  const sContainerCode = oContStatus.code
  if (!sContainerCode) {
    // pas de clé pour ce conteneur
    abort('error.notCodeLocked')
  }
  // rechercher dans notre inventaire un item/clé ayant le tag
  if (sContainerCode === sCode) {
    oLock.locked = false
    print(text('action.youUnlockContainerCode', { container: oContainer.name }))
    print.room(text('action.playerUnlockContainerCode', { container: oContainer.name }))
  } else {
    print(text('action.youFailUnlockContainerCode', { container: oContainer.name }))
  }
}

/**
 * Deverrouillage par clé d'une issue
 * @param context
 * @param sDirection
 */
function unlockDirection (context, sDirection) {
  const { print, engine, pid, text, abort } = context
  const oPlayer = engine.getEntity(pid)
  const oExitStatus = engine.getEntityExit(pid, sDirection)
  if (!oExitStatus.valid) {
    // issue non valide
    abort('error.invalidDirection')
  }
  if (!oExitStatus.locked) {
    // issue non verrouillée
    abort('error.notLocked')
  }
  const sTag = oExitStatus.key
  if (!sTag) {
    // issue non verrouillée par clé
    abort('error.notKeyLocked')
  }
  // rechercher dans notre inventaire un item/clé ayant le tag
  const oKey = engine.findEntitiesByTag(sTag, pid).shift()
  if (oKey) {
    oExitStatus.locked = false
    if (oExitStatus.discardKey) {
      engine.destroyEntity(oKey.id)
      print(text('action.youUnlockExitKeyDiscard', { dir: sDirection, key: oKey.name }))
      print.room(text('action.playerUnlockExitKey', { player: oPlayer.name, dir: sDirection, key: oKey.name }))
    } else {
      print(text('action.youUnlockExitKey', { dir: sDirection, key: oKey.name }))
      print.room(text('action.playerUnlockExitKey', { player: oPlayer.name, dir: sDirection, key: oKey.name }))
    }
  } else {
    print(text('action.youFailUnlockExitKey', { dir: sDirection }))
  }
}

function unlockDirectionCode (context, sDirection, sCode) {
  const { print, engine, pid, text, abort } = context
  const oExitStatus = engine.getEntityExit(pid, sDirection)
  if (!oExitStatus.valid) {
    // issue non valide
    abort('error.invalidDirection')
  }
  if (!oExitStatus.locked) {
    // issue non verrouillée
    abort('error.notLocked')
  }
  if (!oExitStatus.code) {
    abort('error.notCodeLocked')
  }
  const oPlayer = engine.getEntity(pid)
  if (oExitStatus.code === sCode) {
    oExitStatus.locked = false
    print(text('action.youUnlockDoorCode'), { dir: sDirection })
    print.room(text('action.playerUnlockDoorCode', { player: oPlayer.name, dir: sDirection }))
  } else {
    print(text('action.youFailUnlockDoorCode', { dir: sDirection }))
    print.room(text('action.playerFailUnlockDoorCode', { player: oPlayer.name, dir: sDirection }))
  }
}

function main (context, ...params) {
  // verifie le paramètre direction
  rx.dispatch([
    {
      tests: [rx.DIR, rx.ALPHANUM],
      handler: (sDirection, sCode) => unlockDirectionCode(context, sDirection, sCode)
    },
    {
      tests: [rx.LID, rx.ALPHANUM],
      handler: (lid, sCode) => unlockContainerCode(context, lid, sCode)
    },
    {
      tests: [rx.DIR],
      handler: sDirection => unlockDirection(context, sDirection)
    },
    {
      tests: [rx.LID],
      handler: lid => unlockContainer(context, lid)
    },
    {
      // ne correspond à aucune configuration
      handler: () => context.abort('badUsage')
    }
  ], params)
}

module.exports = main
