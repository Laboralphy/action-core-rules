/**
 * Renvoie l'instance du container à partir de son local id
 * le container peut etre placé dans le Room ou dans l'inventaire du joeur
 * @param context
 * @param lidContainer
 */
function getLocalContainer (context, lidContainer) {
  const { engine, pid, abort } = context
  const idRoom = engine.getEntity(pid).location
  let oContainer
  // rechercher le container dans la pièce actuelle
  oContainer = engine.getLocalEntity(lidContainer, idRoom)
  if (!oContainer) {
    // rechercher le container dans l'inventaire du joueur
    oContainer = engine.getLocalEntity(lidContainer, pid)
  }
  if (!oContainer) {
    abort('error.containerNotFound')
  }
  return oContainer
}

/**
 * Renvoie le nom du container contenant l'objet spécifié par l'id
 * @param context
 * @param idEntity {string}
 * @returns {*}
 */
function getContainerName (context, idEntity) {
  const { text, engine, pid } = context
  const id = engine.getParentEntities(idEntity).shift()
  if (id === pid) {
    return text('labels.yourInventory')
  }
  if (engine.isRoomExist(id)) {
    return engine.getRoom(id).name
  } else {
    return engine.getEntity(id).name
  }
}

function springTrap (context, idWhere) {
  const { pid, engine, text, print } = context
  const oPlayer = engine.getEntity(pid)
  const bIsDirection = engine.isDirectionValid(idWhere)
  let trapTag
  if (bIsDirection) {
    const oExitStatus = engine.getEntityExit(pid, idWhere)
    trapTag = oExitStatus.trapTag
  } else {
    const oContainer = engine.getEntity(idWhere)
    trapTag = oContainer.blueprint.trap.tag
  }
  print(text('action.youSpringTrap'))
  if (bIsDirection) {
    print.room(text('action.playerSpringTrap', { player: oPlayer.name, direction: idWhere }))
  } else {
    print.room(text('action.playerSpringContainerTrap', { player: oPlayer.name, container: idWhere }))
  }
  print(text('traps.' + trapTag + '.desc'))
  print(text('traps.' + trapTag + '.player'))
  print.room(text('traps.' + trapTag + '.others', { player: oPlayer.name }))
  // tous les joueurs de la pièce ont repéré le piège
  engine.getLocalEntities(oPlayer.location).forEach(({ lid, id, entity }) => {
    if (entity.blueprint.type === engine.CONST.ENTITY_TYPES.PLAYER) {
      engine.setEntityTrapSpotted(id, idWhere, true)
    }
  })
}

module.exports = {
  getLocalContainer,
  getContainerName,
  springTrap
}
